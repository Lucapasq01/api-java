package com.example.demo;

import com.example.demo.repoentity.IpersonaRepository;
import com.example.demo.repoentity.PersonaRepository;
import com.example.demo.repoentity.RolesRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Service
@Log4j2
public class PersonaService implements IpersonaRepository {


    private PersonaRepository personaRepository;
    public PersonaService(PersonaRepository personaRepository) {
        this.personaRepository = personaRepository;
    }

    @Autowired
    private RolesRepository rolesRepository;



    public List<PersonaDto> findAll() {
        List<Persona> personaEntityList = personaRepository.findAll();

        List<PersonaDto> personaList = new ArrayList<>();
        for (Persona persona : personaEntityList) {
            PersonaDto personaDto = new PersonaDto();
            personaDto.setNome(persona.getNome());
            personaDto.setId(persona.getId());
            personaDto.setDatadiiscrizione(persona.getDatadiiscrizione());
            personaDto.setCodiceFiscale(persona.getCodiceFiscale());
            personaDto.setCognome(persona.getCognome());
            personaDto.setEta(persona.getEta());
            personaDto.setRoles(persona.getRoles());
            personaList.add(personaDto);


        }
         return personaList;
    }




    public PersonaDto findById(Integer id) {
        Optional<Persona> personaOptional = personaRepository.findById(id);
        if (personaOptional.isPresent()) {
            PersonaDto personaDto = new PersonaDto();
            personaDto.setId(personaOptional.get().getId());
            personaDto.setNome(personaOptional.get().getNome());
            personaDto.setCognome(personaOptional.get().getCognome());
            personaDto.setCodiceFiscale(personaOptional.get().getCodiceFiscale());
            personaDto.setEta(personaOptional.get().getEta());
            personaDto.setRoles(personaOptional.get().getRoles());

            personaDto.setDatadiiscrizione(personaOptional.get().getDatadiiscrizione());
            return personaDto;
        }
        return new PersonaDto();
    }

    public void saveUser(Persona u) {

        if(u.getId() == null) {
             personaRepository.save(u);
            Roles roles = new Roles();
            roles.setPersona(u.getId());
            rolesRepository.save(roles);


        }
        else {
            Optional<Persona> userOptional = personaRepository.findById(u.getId());
            if (userOptional.isPresent()) {
                Persona uCopia = userOptional.get();
                uCopia.setNome(u.getNome());
                uCopia.setCognome(u.getCognome());
                uCopia.setCodiceFiscale(u.getCodiceFiscale());
                uCopia.setEta(u.getEta());
                uCopia.setDatadiiscrizione(u.getDatadiiscrizione());
                uCopia.setRoles(u.getRoles());
                uCopia = personaRepository.save(uCopia);

            } else {
                u = personaRepository.save(u);

            }
        }
    }


    public List<Persona> findPaginated(int pageNo, int pageSize) {
        Pageable paging = PageRequest.of(pageNo, pageSize);
        Page<Persona> pagedResult = personaRepository.findAll(paging);

        return pagedResult.toList();
    }
}



