package com.example.demo;

public enum Role_type {
    user,
    admin,
    super_admin;
}
