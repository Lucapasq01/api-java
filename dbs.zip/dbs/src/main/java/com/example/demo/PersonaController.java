package com.example.demo;


import com.example.demo.repoentity.PersonaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Optional;

@Controller
public class PersonaController {

     @Autowired
     private PersonaRepository personaRepository;


    @Autowired
    private PersonaService personaService;



    @NonNull
    @ResponseBody
    @GetMapping("/API/{pageNo}/{pageSize}")
    public List<Persona> getPaginatedCountries(@PathVariable int pageNo,
                                               @PathVariable int pageSize) {

        return personaService.findPaginated(pageNo, pageSize);
    }

    @ResponseBody
    @GetMapping(value = "/API/getAll")
    public List<PersonaDto>  getAll(){
        return personaService.findAll();
    }

    @ResponseBody
    @GetMapping(value = "/API/getId/{id}")
    public Optional<PersonaDto> getId(@PathVariable Integer id){
        return Optional.ofNullable(personaService.findById(id));
    }


    @GetMapping("/")
    public String home(Persona persona ,  Model model){
        List<PersonaDto> list=personaService.findAll();
      model.addAttribute("list",list);
        return "index";
    }
    @GetMapping("/form")
    public String form (PersonaDto personaDto){
        return "form";
    }

    @PostMapping("/save")
    public String save(Persona persona , Model model){
        model.addAttribute("form", persona);
        personaService.saveUser(persona);
        return "redirect:/";
    }
  }
