package com.example.demo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.management.relation.Role;
import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "persona")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Persona {

 @Id
 @GeneratedValue (strategy = GenerationType.IDENTITY)
 @Column(name="id",nullable = false)
 private Integer id;
 @Column(name="nome")
 private String nome;

 @Column(name="cognome")
 private String cognome;

 @Column(name="eta")
 private String eta;

 @Column(name="codicefiscale")
 private String codiceFiscale;

 @Column(name="datadiiscrizione")
 private String datadiiscrizione;

 @OneToMany( fetch =FetchType.EAGER)
 @JoinColumn (name="persona_id",referencedColumnName ="id")
 private List<Roles>roles;


}



