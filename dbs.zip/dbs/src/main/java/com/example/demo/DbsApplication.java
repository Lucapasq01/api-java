package com.example.demo;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@Log4j2
public class DbsApplication implements CommandLineRunner {

	@Autowired
	private PersonaService userService;




	public static void main(String[] args) {
		SpringApplication.run(DbsApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		log.info(userService.findAll().toString());

	}

}
