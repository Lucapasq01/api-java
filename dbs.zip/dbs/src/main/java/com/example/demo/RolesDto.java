package com.example.demo;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class RolesDto {
    private Integer id;
    private Integer persona_id;
    private String role_type;
}
