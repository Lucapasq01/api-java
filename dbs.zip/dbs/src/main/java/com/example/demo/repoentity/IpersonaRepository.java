package com.example.demo.repoentity;

import com.example.demo.Persona;

import java.util.List;

public interface IpersonaRepository {
    List<Persona> findPaginated(int pageNo, int pageSize);
}
