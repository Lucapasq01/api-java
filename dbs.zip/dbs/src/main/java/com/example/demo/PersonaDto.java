package com.example.demo;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@Data

public class PersonaDto {

    private Integer id;
    private String nome;
    private String cognome;
    private String eta;
    private String codiceFiscale;
    private String datadiiscrizione;
    private List<Roles> roles;



}
